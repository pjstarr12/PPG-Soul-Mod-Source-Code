using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace Mod
{
    public class MonsterSoulBehaviour : MonoBehaviour
    {
        public LimbBehaviour BeforeLimb;
        public PersonBehaviour Person;
        public Sprite BrokenHeart = ModAPI.LoadSprite("MonsterBrokenHeart.png");
        public Sprite HeartShard2 = ModAPI.LoadSprite("MonsterShard.png");
        public Sprite HeartShapedObject = ModAPI.LoadSprite("MonsterHeart.png");
        public GameObject cObj;
        public SpriteRenderer cSpr;
        public Transform Head;
        public bool Dead = false;

        void Awake(){
            Person = this.gameObject.GetComponent<PersonBehaviour>();
            Head = this.gameObject.transform.GetChild(6).GetChild(0);
            cObj = new GameObject("MonsterHeartObject");
            cObj.transform.SetParent(Head);
            cObj.transform.localPosition = new Vector3(0.099f, 0f);
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            cObj.transform.localScale = new Vector3(1.1f, 1.1f);
            cSpr = cObj.AddComponent<SpriteRenderer>();
            cSpr.sprite = HeartShapedObject;
            cSpr.sortingLayerName = "Top";
        }
        void Update() {
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 180f);
            foreach (LimbBehaviour p2 in Person.Limbs) {
                BeforeLimb = p2;
                foreach (LimbBehaviour p3 in Person.Limbs) {
                    if (p3.gameObject.name == "Head" && p3.Health <= 0f) {
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && p3.Broken == true) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasCirculation) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasCirculation) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    }
                };
            };
        }
        IEnumerator BreakHeartWait() {
            if (Dead == false) {
                Dead = true;
                Vector3 normalized = (Vector3) Random.insideUnitCircle.normalized;
                cObj.transform.localPosition = new Vector3(0.099f, 0f);
                yield return (object) new WaitForSeconds(1f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.09f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.09f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.08f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.07f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.05f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.03f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.02f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.02f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.01f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.01f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.01f);
                cObj.transform.localPosition = new Vector3(0.099f, 0f);
                cObj.GetComponent<SpriteRenderer>().sprite = BrokenHeart;
                yield return (object) new WaitForSeconds(1f);
                cObj.GetComponent<SpriteRenderer>().enabled = false;
                var HeartShard = new GameObject("MonsterHeartShard");
                HeartShard.transform.SetParent(Head);
                HeartShard.layer = 10;
                HeartShard.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
                HeartShard.transform.localScale = new Vector3(1f, 1f);
                HeartShard.transform.position = Head.position;
                var cHeartShard1Spr = HeartShard.AddComponent<SpriteRenderer>();
                cHeartShard1Spr.sprite = HeartShard2;
                var cHeartShard1rb = HeartShard.AddComponent<Rigidbody2D>();
                HeartShard.FixColliders();
                GameObject instance2 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance3 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance4 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance5 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance6 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance7 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                instance2.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 2f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance3.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 2f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance4.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 2f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance5.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 2f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance6.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 2f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance7.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 2f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                ModAPI.Notify("The developer will make particles soon!");
                Destroy(this.gameObject);
            }
        }
    }
}