using UnityEngine;
using UnityEngine.Events;
using System.Collections;
using System.Collections.Generic;
namespace Mod
{
    public class CustomHeartBehaviour : MonoBehaviour
    {
        public DialogBox dialog = (DialogBox)null;
        List<ContextMenuButton> buttonsList;
        public LimbBehaviour BeforeLimb;
        public PersonBehaviour Person;
        public Sprite BrokenHeart = ModAPI.LoadSprite("MonsterBrokenHeart.png");
        public Sprite HeartShard2 = ModAPI.LoadSprite("HeartShard1.png");
        public Sprite HeartShard3 = ModAPI.LoadSprite("HeartShard2.png");
        public Sprite HeartShapedObject = ModAPI.LoadSprite("Heart.png");
        public GameObject cObj;
        public SpriteRenderer cSpr;
        public Transform Head;
        public bool Dead = false;
        public float r = 255f;
        public float g = 0f;
        public float b = 0f;

        void Awake(){
            Person = this.gameObject.GetComponent<PersonBehaviour>();
            Head = this.gameObject.transform.GetChild(6).GetChild(0);
            cObj = new GameObject("HeartObject");
            cObj.transform.SetParent(Head);
            cObj.transform.localPosition = new Vector3(0.099f, 0f);
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            cObj.transform.localScale = new Vector3(1.1f, 1.1f);
            cSpr = cObj.AddComponent<SpriteRenderer>();
            cSpr.sprite = HeartShapedObject;
            cSpr.sortingLayerName = "Top";
        }
        void Start() { 
            foreach (var p in Person.Limbs) {
                buttonsList = p.GetComponent<PhysicalBehaviour>().ContextMenuOptions.Buttons;
                ContextMenuButton setRValue = new ContextMenuButton(() => true, "setRValue", "Set R Value", "Set R Value", new UnityAction[1]
                {
                    (UnityAction) (() => Utils.OpenFloatInputDialog<CustomHeartBehaviour>(255, this, (System.Action<CustomHeartBehaviour, float>) ((t, v) =>
                    {
                        r = v;
                        UpdateColor();
                    }), "R Value", "your mom"))
                });
                ContextMenuButton setGValue = new ContextMenuButton(() => true, "setGValue", "Set G Value", "Set G Value", new UnityAction[1]
                {
                    (UnityAction) (() => Utils.OpenFloatInputDialog<CustomHeartBehaviour>(0, this, (System.Action<CustomHeartBehaviour, float>) ((t, v) =>
                    {
                        g = v;
                        UpdateColor();
                    }), "G Value", "your mom"))
                });
                ContextMenuButton setBValue = new ContextMenuButton(() => true, "setBValue", "Set B Value", "Set B Value", new UnityAction[1]
                {
                    (UnityAction) (() => Utils.OpenFloatInputDialog<CustomHeartBehaviour>(0, this, (System.Action<CustomHeartBehaviour, float>) ((t, v) =>
                    {
                        b = v;
                        UpdateColor();
                    }), "R Value", "your mom"))
                });
                buttonsList.Add(setRValue);
                buttonsList.Add(setGValue);
                buttonsList.Add(setBValue);
            }
        }
        void Update() {
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            Person.AdrenalineLevel = 1f;
            foreach (LimbBehaviour p2 in Person.Limbs) {
                BeforeLimb = p2;
                p2.BreakingThreshold += 10f;
                p2.CirculationBehaviour.InternalBleedingIntensity *= 0.8f;
                p2.ImpactPainMultiplier *= 0.2f;
                p2.Vitality *= 0.1f;
                p2.SkinMaterialHandler.RottenProgress *= 0.8f;
                foreach (LimbBehaviour p3 in Person.Limbs) {
                    if (p3.gameObject.name == "Head" && p3.Health <= 0f) {
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && p3.Broken == true) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasCirculation) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasCirculation) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    }
                };
            };
        }
        IEnumerator BreakHeartWait() {
            if (Dead == false) {
                Dead = true;
                Vector3 normalized = (Vector3) UnityEngine.Random.insideUnitCircle.normalized;
                cObj.transform.localPosition = new Vector3(0.099f, 0f);
                yield return new WaitForSeconds(1f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.09f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return new WaitForSeconds(0.09f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.08f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return new WaitForSeconds(0.07f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.05f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return new WaitForSeconds(0.03f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.02f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return new WaitForSeconds(0.02f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.01f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return new WaitForSeconds(0.01f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return new WaitForSeconds(0.01f);
                cObj.transform.localPosition = new Vector3(0.099f, 0f);
                cObj.GetComponent<SpriteRenderer>().sprite = BrokenHeart;
                yield return new WaitForSeconds(1f);
                cObj.GetComponent<SpriteRenderer>().enabled = false;
                var HeartShard = new GameObject("HeartShard");
                HeartShard.transform.SetParent(Head);
                HeartShard.layer = 10;
                HeartShard.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
                HeartShard.transform.localScale = new Vector3(1f, 1f);
                HeartShard.transform.position = Head.position;
                var cHeartShard1Spr = HeartShard.AddComponent<SpriteRenderer>();
                cHeartShard1Spr.sprite = HeartShard2;
                cHeartShard1Spr.color = new Color(r, g, b);
                var cHeartShard1rb = HeartShard.AddComponent<Rigidbody2D>();
                HeartShard.FixColliders();
                GameObject instance = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance2 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance3 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                GameObject instance4 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                instance.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance2.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance3.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                instance4.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                Destroy(this.gameObject);
            }
        }
        void UpdateColor() {
            cSpr.color = new Color(r, g, b);
        }
    }
} 