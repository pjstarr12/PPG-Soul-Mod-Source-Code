using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace Mod
{
    public class SansAttack : MonoBehaviour
    {
        public void Use(ActivationPropagation activation)
        {
            GameObject instance = Object.Instantiate<GameObject>(ModAPI.FindSpawnable("Bone Sword -HSM").Prefab, this.gameObject.transform.position, this.gameObject.transform.rotation); //Quaternion.Identity);
            //instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("HeartNoColor.png");
            instance.GetComponent<Rigidbody2D>().AddForce(-this.gameObject.transform.up * 7, ForceMode2D.Impulse);
        }
    }
}