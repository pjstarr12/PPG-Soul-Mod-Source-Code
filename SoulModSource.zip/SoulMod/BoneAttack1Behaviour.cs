using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace Mod
{
    public class BoneAttack1Behaviour : MonoBehaviour
    {

        public void Use(ActivationPropagation activation)
        {
            this.gameObject.GetComponent<Rigidbody2D>().AddForce(this.gameObject.transform.up * 7, ForceMode2D.Impulse);
        }
    }
}