using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace Mod
{
    public class HeartBehaviour : MonoBehaviour
    {
        public bool Dead = false;
        public LimbBehaviour BeforeLimb;
        public PersonBehaviour Person;
        public Sprite BrokenHeart = ModAPI.LoadSprite("BrokenHeartNoColor.png");
        public Sprite HeartShard2 = ModAPI.LoadSprite("HeartShard1NoColor.png");
        public Sprite HeartShapedObject = ModAPI.LoadSprite("HeartNoColor.png");
        public Texture2D t90 = ModAPI.LoadTexture("t90.png");
        public Texture2D t80 = ModAPI.LoadTexture("t80.png");
        public Texture2D t70 = ModAPI.LoadTexture("t70.png");
        public Texture2D t60 = ModAPI.LoadTexture("t60.png");
        public Texture2D t50 = ModAPI.LoadTexture("t50.png");
        public Texture2D t40 = ModAPI.LoadTexture("t40.png");
        public Texture2D t30 = ModAPI.LoadTexture("t30.png");
        public Texture2D t20 = ModAPI.LoadTexture("t20.png");
        public Texture2D t10 = ModAPI.LoadTexture("t10.png");
        public Texture2D t0 = ModAPI.LoadTexture("t0.png");
        public GameObject cObj;
        public GameObject Shield;
        public SpriteRenderer ShieldSprite;
        public SpriteRenderer ShardSprite;
        public SpriteRenderer cSpr;
        public Transform Head;
        public Transform Torso;
        public Transform LTorso;
        public Transform HeadReal;
        public AudioSource HeartBreakSound;
        public AudioSource UnHeartBreakSound;
        public Rigidbody2D HeadRB;
        public Rigidbody2D TorsoRB;
        public Rigidbody2D MTorsoRB;
        public Rigidbody2D LTorsoRB;
        public BoxCollider2D ShieldCollider;

        void Awake(){
            Person = this.gameObject.GetComponent<PersonBehaviour>();
            Head = this.gameObject.transform.GetChild(6).GetChild(0);
            cObj = new GameObject("HeartObject");
            cObj.transform.SetParent(Head);
            cObj.transform.localPosition = new Vector3(0.099f, 0f);
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            cObj.transform.localScale = new Vector3(1.1f, 1.1f);
            cSpr = cObj.AddComponent<SpriteRenderer>();
            cSpr.sprite = HeartShapedObject;
            cSpr.sortingLayerName = "Top";

            HeartBreakSound = cObj.AddComponent<AudioSource>();
            HeartBreakSound.clip = ModAPI.LoadSound("HeartBreak.mp3");
            UnHeartBreakSound = this.gameObject.AddComponent<AudioSource>();
            UnHeartBreakSound.clip = ModAPI.LoadSound("snd_break1_c.wav");
        }
        void Update() {
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            Person.AdrenalineLevel = 1f;
            foreach (LimbBehaviour p2 in Person.Limbs) {
                BeforeLimb = p2;
                p2.BreakingThreshold += 10f;
                p2.CirculationBehaviour.InternalBleedingIntensity *= 0.8f;
                p2.ImpactPainMultiplier *= 0.2f;
                p2.Vitality *= 0.1f;
                p2.SkinMaterialHandler.RottenProgress *= 0.8f;
                foreach (LimbBehaviour p3 in Person.Limbs) {
                    if (p3.gameObject.name == "Head" && p3.Health <= 0f) {
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && p3.Broken == true) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasCirculation) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasCirculation) { 
                        StartCoroutine("BreakHeartWait");
                        BeforeLimb.gameObject.layer = 10;
                        BeforeLimb.CirculationBehaviour.HealBleeding();
                        //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                        FreezeStackController.RequestFreeze(BeforeLimb.gameObject.GetComponent<Rigidbody2D>());
                    }
                };
            };
        }
        IEnumerator BreakHeartWait() {
            if (Dead == false) {
                Dead = true;
                if (UnityEngine.Random.Range(1, 5) == 1) {
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t90, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t80, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t70, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t60, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t50, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t40, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t30, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t20, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t10, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t0, null, null, 1);
                    yield return (object) new WaitForSeconds(0.5f); 
                    cObj.transform.localPosition = new Vector3(0.099f, 0f);
                    yield return (object) new WaitForSeconds(1f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.08f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.07f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.05f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.03f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.GetComponent<SpriteRenderer>().sprite = BrokenHeart;
                    UnHeartBreakSound.Play();
                    yield return (object) new WaitForSeconds(2.5f);
                    UnHeartBreakSound.Play();
                    cObj.GetComponent<SpriteRenderer>().sprite = HeartShapedObject;
                    ModAPI.Notify("* But it refused.");
                    //createMessage("* But it refused.", new Color(255, 255, 255), cObj.transform.position += new Vector3(0f, 1f, 0f));
                    yield return (object) new WaitForSeconds(0.5f);
                    //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                    foreach (LimbBehaviour p3 in Person.Limbs) {
                        Person.SetBodyTextures(null, null, null, 1);
                        p3.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
                        BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
                        p3.LungsPunctured = false;
                        p3.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                        BeforeLimb.HealBone();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                        BeforeLimb.LungsPunctured = false;
                        BeforeLimb.Health = BeforeLimb.InitialHealth;
                        BeforeLimb.CirculationBehaviour.IsPump = true;
                        BeforeLimb.CirculationBehaviour.BloodFlow = 1f;
                        BeforeLimb.gameObject.layer = 9;
                        p3.Health = p3.InitialHealth;
                        p3.CirculationBehaviour.IsPump = true;
                        p3.CirculationBehaviour.BloodFlow = 1f;
                        p3.gameObject.layer = 9;
                        p3.HealBone();
                    }
                    Person.Consciousness = 1f;
                    Person.ShockLevel = 0.0f;
                    Person.PainLevel = 0.0f;
                    Person.OxygenLevel = 1f;
                    Person.AdrenalineLevel = 1f;
                    Dead = false;
                } else {
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t90, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t80, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t70, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t60, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t50, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t40, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t30, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t20, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t10, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t0, null, null, 1);
                    yield return (object) new WaitForSeconds(0.5f);
                    Vector3 normalized = (Vector3) Random.insideUnitCircle.normalized;
                    cObj.transform.localPosition = new Vector3(0.099f, 0f);
                    yield return (object) new WaitForSeconds(1f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.08f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.07f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.05f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.03f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.localPosition = new Vector3(0.099f, 0f);
                    HeartBreakSound.Play();
                    cObj.GetComponent<SpriteRenderer>().sprite = BrokenHeart;
                    yield return (object) new WaitForSeconds(1.2f);
                    cObj.GetComponent<SpriteRenderer>().enabled = false;
                    var HeartShard = new GameObject("HeartShard");
                    HeartShard.transform.SetParent(Head);
                    HeartShard.layer = 10;
                    HeartShard.transform.rotation = Quaternion.Euler(0f, 0f, Random.Range(-360f, 360f));
                    HeartShard.transform.localScale = new Vector3(1f, 1f);
                    HeartShard.transform.position = Head.position;
                    ShardSprite = HeartShard.AddComponent<SpriteRenderer>();
                    ShardSprite.sprite = HeartShard2;
                    //if (IsBlue && !IsGreen && !IsPurple) { 
                    //    ShardSprite.color = new Color(0, 0, 255);
                    //} else if (IsGreen && !IsBlue && !IsPurple) {
                    //    ShardSprite.color = new Color(0, 255, 0);
                    //} else if (IsPurple && !IsBlue && !IsGreen) { 
                    //    ShardSprite.color = new Color(255, 0, 255);
                    //} else { 
                    //    ShardSprite.color = new Color(255, 0, 0);
                    //}
                    var cHeartShard1rb = HeartShard.AddComponent<Rigidbody2D>();
                    HeartShard.FixColliders();
                    GameObject instance = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance2 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance3 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance4 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance5 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance6 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    instance.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance2.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance3.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance4.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance5.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance6.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    yield return (object) new WaitForSeconds(2f);
                    Destroy(this.gameObject);
                }

            }
        }
    }
}