using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
namespace Mod
{
    public class BIRBehaviour : MonoBehaviour
    {
        public bool Dead = false;
        public bool GoingDead = false;
        public bool IsBlue = false;
        public bool IsGreen = false;
        public bool IsPurple = false;
        public LimbBehaviour BeforeLimb;
        public PersonBehaviour Person;
        public Sprite BrokenHeart = ModAPI.LoadSprite("BrokenHeartNoColor.png");
        public Sprite HeartShard2 = ModAPI.LoadSprite("HeartShard1NoColor.png");
        public Sprite HeartShapedObject = ModAPI.LoadSprite("HeartNoColor.png");
        public Sprite SpriteShield = ModAPI.LoadSprite("Shield.png");
        public Texture2D t90 = ModAPI.LoadTexture("t90.png");
        public Texture2D t80 = ModAPI.LoadTexture("t80.png");
        public Texture2D t70 = ModAPI.LoadTexture("t70.png");
        public Texture2D t60 = ModAPI.LoadTexture("t60.png");
        public Texture2D t50 = ModAPI.LoadTexture("t50.png");
        public Texture2D t40 = ModAPI.LoadTexture("t40.png");
        public Texture2D t30 = ModAPI.LoadTexture("t30.png");
        public Texture2D t20 = ModAPI.LoadTexture("t20.png");
        public Texture2D t10 = ModAPI.LoadTexture("t10.png");
        public Texture2D t0 = ModAPI.LoadTexture("t0.png");
        public GameObject cObj;
        public GameObject Shield;
        public SpriteRenderer ShieldSprite;
        public SpriteRenderer ShardSprite;
        public SpriteRenderer cSpr;
        public Transform Head;
        public Transform Torso;
        public Transform LTorso;
        public Transform HeadReal;
        public AudioSource HeartBreakSound;
        public AudioSource SoulPing;
        public AudioSource UnHeartBreak;
        public Rigidbody2D HeadRB;
        public Rigidbody2D TorsoRB;
        public Rigidbody2D MTorsoRB;
        public Rigidbody2D LTorsoRB;
        public BoxCollider2D ShieldCollider;

        void Awake(){                  /////////////////////////////////////////////////////////////////////KEYBIND THAT MAKES BLUE SOUL GO VROOM
            Person = this.gameObject.GetComponent<PersonBehaviour>();
            Head = this.gameObject.transform.GetChild(6).GetChild(0);
            Torso = this.gameObject.transform.GetChild(6).GetChild(1);
            LTorso = this.gameObject.transform.GetChild(6).GetChild(2);
            HeadReal = this.gameObject.transform.GetChild(5);
            HeadRB = HeadReal.GetComponent<Rigidbody2D>();
            TorsoRB = Head.GetComponent<Rigidbody2D>();
            MTorsoRB = Torso.GetComponent<Rigidbody2D>();
            LTorsoRB = LTorso.GetComponent<Rigidbody2D>();
            cObj = new GameObject("HeartObject");
            //cObj.AddComponent<ExistInDetailView>();
            cObj.transform.SetParent(Head);
            cObj.transform.localPosition = new Vector3(0.099f, 0f);
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            cObj.transform.localScale = new Vector3(1.1f, 1.1f);
            cSpr = cObj.AddComponent<SpriteRenderer>();
            cSpr .sprite = HeartShapedObject;
            cSpr.sortingLayerName = "Top";
            HeartBreakSound = cObj.AddComponent<AudioSource>();
            HeartBreakSound.clip = ModAPI.LoadSound("HeartBreak.mp3");
            SoulPing = cObj.AddComponent<AudioSource>();
            SoulPing.clip = ModAPI.LoadSound("SoulPingReal.wav");
            UnHeartBreak = this.gameObject.AddComponent<AudioSource>();
            UnHeartBreak.clip = ModAPI.LoadSound("snd_break1_c.wav");

            //shield 
            Shield = new GameObject("Shield");
            //Shield.layer = 9;
            Shield.transform.SetParent(Torso);
            Shield.transform.localPosition = new Vector3(0.85f, 0f);
            Shield.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            Shield.transform.localScale = new Vector3(1f, 1f);
            ShieldSprite = Shield.AddComponent<SpriteRenderer>();
            ShieldSprite.sprite = SpriteShield;
            ShieldSprite.enabled = false;
            //ShieldCollider = Shield.AddComponent<BoxCollider2D>();
            //Shield.FixColliders();
            //ShieldCollider.enabled = false;

            //fix color
            
            //if (IsBlue && !IsGreen) { 
            //    cSpr.color = new Color(0, 0, 255);
            //} else if (IsGreen && !IsBlue) {
            //    cSpr.color = new Color(0, 255, 0);
            //} else { 
            //    cSpr.color = new Color(255, 0, 0);
            //}
            
        }
        void Start() { 
            foreach (var p in Person.Limbs) {
                List<ContextMenuButton> buttonsList = p.PhysicalBehaviour.ContextMenuOptions.Buttons;
                
                var ToggleBlue = new ContextMenuButton(() => Person.IsAlive(), "ToggleBlue", "Toggle Blue", "Toggle the Human's SOUL to red or blue.", new UnityAction[1]
                {
                    (UnityAction) (() => {
                        if (IsBlue) {
                            IsGreen = false;
                            IsBlue = false;
                            IsPurple = false;
                            SoulPing.Play();
                        } else if (IsGreen) {
                            ShieldSprite.enabled = false; 
                            SoulPing.Play();
                            IsGreen = false;
                            IsBlue = true;
                            IsPurple = false;
                            ModAPI.Notify("Use the [[arrowkeys]] to move the human's [HeartShapedObject]");
                        } else if (IsPurple){
                            IsGreen = false;
                            IsPurple = false;
                            SoulPing.Play();
                            IsBlue = true;
                            ModAPI.Notify("Use the [[arrowkeys]] to move the human's [HeartShapedObject]");
                        }
                    })
                });

                var TogglePurple = new ContextMenuButton(() => Person.IsAlive(), "TogglePurple", "Toggle Purple", "Toggle the Human's SOUL to red or Purple.", new UnityAction[1]
                {
                    (UnityAction) (() => {
                        if (IsBlue) {
                            IsGreen = false;
                            IsBlue = false;
                            IsPurple = true;
                            ShieldSprite.enabled = false; 
                            SoulPing.Play();
                            ModAPI.Notify("Purple soul mode dosent do anything yet");
                        } else if (!IsBlue) {
                            IsGreen = false;
                            IsBlue = false;
                            IsPurple = true;
                            ShieldSprite.enabled = false; 
                            SoulPing.Play();
                            ModAPI.Notify("Purple soul mode dosent do anything yet");
                        } else if (IsGreen){
                            IsGreen = false;
                            IsBlue = false;
                            IsPurple = true;
                            ShieldSprite.enabled = false; 
                            SoulPing.Play();
                            ModAPI.Notify("Purple soul mode dosent do anything yet");
                        }
                    })
                });

                var ToggleGreen = new ContextMenuButton(() => Person.IsAlive(), "ToggleGreen", "Toggle Green", "Toggle the Human's SOUL to red or Green.", new UnityAction[1]
                {
                    (UnityAction) (() => {
                        if (IsGreen) {
                            SoulPing.Play();
                            IsGreen = false;
                            IsPurple = false;
                            IsBlue = false;
                            ShieldSprite.enabled = false;
                        } else if (IsPurple) {
                            ShieldSprite.enabled = true;
                            SoulPing.Play();
                            IsGreen = true;
                            IsPurple = false;
                            IsBlue = false;
                            ModAPI.Notify("THE SHIELD DOSENT COLLIDE WITH ANYTHING YET!!!");
                        } else if (IsBlue) {
                            ShieldSprite.enabled = true;
                            SoulPing.Play();
                            IsGreen = true;
                            IsPurple = false;
                            IsBlue = false;
                            ModAPI.Notify("THE SHIELD DOSENT COLLIDE WITH ANYTHING YET!!!");
                        }
                    })
                });
                var ChangeRed = new ContextMenuButton(() => Person.IsAlive(), "ToggleRed", "Toggle Red", "Change the Human's SOUL to red", new UnityAction[1]
                {
                    (UnityAction) (() => {
                        IsBlue = false;
                        IsPurple = false;
                        IsGreen = false;
                    })
                });
                buttonsList.Add(ChangeRed);
                buttonsList.Add(ToggleGreen);
                buttonsList.Add(TogglePurple);
                buttonsList.Add(ToggleBlue);
            }
        }
        void Update() {
            if (Input.GetKeyDown(KeyCode.LeftArrow)) {
                if (IsBlue && !IsGreen) {
                    TorsoRB.AddForce((Vector2) (new Vector3(-100, 0, 0) * Mathf.Max(TorsoRB.mass, 1f)));
                    HeadRB.AddForce((Vector2) (new Vector3(-100, 0, 0) * Mathf.Max(HeadRB.mass, 1f)));
                    MTorsoRB.AddForce((Vector2) (new Vector3(-100, 0, 0) * Mathf.Max(MTorsoRB.mass, 1f)));
                    LTorsoRB.AddForce((Vector2) (new Vector3(-100, 0, 0) * Mathf.Max(LTorsoRB.mass, 1f)));
                } else if (IsGreen && !IsBlue) {
                    SoulPing.Play(); 
                    ShieldSprite.flipX = true;
                    ShieldSprite.flipY = false;
                    Shield.transform.localPosition = new Vector3(-0.85f, 0f);
                    Shield.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
                    Shield.FixColliders();
                }
            } else if (Input.GetKeyDown(KeyCode.DownArrow)) {
                if (IsBlue && !IsGreen) { 
                    TorsoRB.AddForce((Vector2) (new Vector3(0, -100, 0) * Mathf.Max(TorsoRB.mass, 1f)));
                    HeadRB.AddForce((Vector2) (new Vector3(0, -100, 0) * Mathf.Max(HeadRB.mass, 1f)));
                    MTorsoRB.AddForce((Vector2) (new Vector3(0, -100, 0) * Mathf.Max(MTorsoRB.mass, 1f)));
                    LTorsoRB.AddForce((Vector2) (new Vector3(0, -100, 0) * Mathf.Max(LTorsoRB.mass, 1f)));
                }
            } else if (Input.GetKeyDown(KeyCode.UpArrow)) {
                if (IsBlue && !IsGreen) { 
                    TorsoRB.AddForce((Vector2) (new Vector3(0, 100, 0) * Mathf.Max(TorsoRB.mass, 1f)));
                    HeadRB.AddForce((Vector2) (new Vector3(0, 100, 0) * Mathf.Max(HeadRB.mass, 1f)));
                    MTorsoRB.AddForce((Vector2) (new Vector3(0, 100, 0) * Mathf.Max(MTorsoRB.mass, 1f)));
                    LTorsoRB.AddForce((Vector2) (new Vector3(0, 100, 0) * Mathf.Max(LTorsoRB.mass, 1f)));
                } else if (IsGreen && !IsBlue) {
                    SoulPing.Play();
                    ShieldSprite.flipY = true;
                    Shield.transform.localPosition = new Vector3(0f, 1f);
                    if (Shield.transform.rotation == Quaternion.Euler(0f, 0f, 0f)) { 
                        Shield.transform.rotation = Quaternion.Euler(0f, 0f, -90f);
                    } else { 
                        Shield.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
                    }
                    
                    Shield.FixColliders();
                }
            } else if (Input.GetKeyDown(KeyCode.RightArrow)) {
                if (IsBlue && !IsGreen) { 
                    TorsoRB.AddForce((Vector2) (new Vector3(100, 0, 0) * Mathf.Max(TorsoRB.mass, 1f)));
                    HeadRB.AddForce((Vector2) (new Vector3(100, 0, 0) * Mathf.Max(HeadRB.mass, 1f)));
                    MTorsoRB.AddForce((Vector2) (new Vector3(100, 0, 0) * Mathf.Max(MTorsoRB.mass, 1f)));
                    LTorsoRB.AddForce((Vector2) (new Vector3(100, 0, 0) * Mathf.Max(LTorsoRB.mass, 1f)));
                } else if (IsGreen && !IsBlue) {
                    SoulPing.Play(); 
                    ShieldSprite.flipX = false;
                    ShieldSprite.flipY = false;
                    Shield.transform.localPosition = new Vector3(0.85f, 0f);
                    Shield.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
                    Shield.FixColliders();
                }
            }


            //GREEN SHIT
            if (IsGreen && !IsBlue) {
                ShieldSprite.enabled = true;
            } else { 
                ShieldSprite.enabled = false;
            }


            if (IsBlue && !IsGreen && !IsPurple) { 
                cSpr.color = new Color(0, 0, 255);
            } else if (IsGreen && !IsBlue && !IsPurple) {
                cSpr.color = new Color(0, 255, 0);
            } else if (IsPurple && !IsBlue && !IsGreen) {
                cSpr.color = new Color(255, 0, 255);
            } else { 
                cSpr.color = new Color(255, 0, 0);
            }
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            Person.AdrenalineLevel = 1f;
            foreach (LimbBehaviour p2 in Person.Limbs) {
                BeforeLimb = p2;
                p2.BreakingThreshold += 1f;
                p2.CirculationBehaviour.InternalBleedingIntensity *= 0.4f;
                p2.ImpactPainMultiplier *= 0.1f;
                p2.Vitality *= 0.03f;
                p2.SkinMaterialHandler.RottenProgress *= 0.6f;
                foreach (LimbBehaviour p3 in Person.Limbs) {
                    if (p3.gameObject.name == "Head" && p3.Health <= 0f) {
                        //if (!GoingDead) { 
                        //    GoingDead = true;
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                        //}
                    } else if (p3.gameObject.name == "Head" && p3.Broken == true) { 
                        //if (!GoingDead) { 
                        //    GoingDead = true;
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                        //}
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        //if (!GoingDead) { 
                        //    GoingDead = true;
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                        //}
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasBloodFlow) { 
                        //if (!GoingDead) { 
                        //    GoingDead = true;
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                        //}
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasCirculation) { 
                        //if (!GoingDead) {
                        //    GoingDead = true;
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                        //}
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasCirculation) { 
                        //if (!GoingDead) { 
                        //    GoingDead = true;
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                        //}
                    }
                };
            };
        }
        IEnumerator BreakHeartWait() {
            if (Dead == false) {
                Dead = true;
                if (UnityEngine.Random.Range(1, 10) == 1) {
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t90, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t80, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t70, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t60, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t50, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t40, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t30, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t20, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t10, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    foreach (LimbBehaviour p4 in Person.Limbs) {
                        p4.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                    }
                    yield return (object) new WaitForSeconds(0.8f);
                    cObj.transform.localPosition = new Vector3(0.099f, 0f);
                    yield return (object) new WaitForSeconds(1f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.08f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.07f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.05f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.03f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.GetComponent<SpriteRenderer>().sprite = BrokenHeart;
                    UnHeartBreak.Play();
                    yield return (object) new WaitForSeconds(2.5f);
                    UnHeartBreak.Play();
                    cObj.GetComponent<SpriteRenderer>().sprite = HeartShapedObject;
                    ModAPI.Notify("* But it refused.");
                    Person.SetBodyTextures(null, null, null, 1);
                    foreach (LimbBehaviour p4 in Person.Limbs) {
                        p4.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                    }
                    //createMessage("* But it refused.", new Color(255, 255, 255), cObj.transform.position += new Vector3(0f, 1f, 0f));
                    //yield return (object) new WaitForSeconds(0.5f);
                    //Person.SetBodyTextures(t10, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t20, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t30, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t40, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t50, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t60, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t70, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t80, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(t90, null, null, 1);
                    //yield return (object) new WaitForSeconds(0.1f);
                    //Person.SetBodyTextures(ModAPI.LoadTexture("BaseSkin.png"), ModAPI.LoadTexture("defaultflesh.png"), ModAPI.LoadTexture("defaultbone.png"), 1);
                    foreach (LimbBehaviour p3 in Person.Limbs) {
                        p3.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                        p3.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
                        BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
                        p3.LungsPunctured = false;
                        p3.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                        BeforeLimb.HealBone();
                        BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                        BeforeLimb.LungsPunctured = false;
                        BeforeLimb.Health = BeforeLimb.InitialHealth;
                        BeforeLimb.CirculationBehaviour.IsPump = true;
                        BeforeLimb.CirculationBehaviour.BloodFlow = 1f;
                        BeforeLimb.gameObject.layer = 9;
                        p3.Health = p3.InitialHealth;
                        p3.CirculationBehaviour.IsPump = true;
                        p3.CirculationBehaviour.BloodFlow = 1f;
                        p3.gameObject.layer = 9;
                        p3.HealBone();
                        Dead = false;
                    }
                    //Person.SetBodyTextures(ModAPI.LoadTexture("BaseSkin.png"), ModAPI.LoadTexture("defaultflesh.png"), ModAPI.LoadTexture("defaultbone.png"), 1);
                    //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                    //Person.Consciousness = 1f;
                    //Person.ShockLevel = 0.0f;
                    //Person.PainLevel = 0.0f;
                    //Person.OxygenLevel = 1f;
                    //Person.AdrenalineLevel = 1f;
                    Dead = false;

                } else { 
                    //Destroy(cObj.GetComponent<ExistInDetailView>());
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t90, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t80, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t70, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t60, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t50, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t40, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t30, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t20, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t10, null, null, 1);
                    yield return (object) new WaitForSeconds(0.1f);
                    Person.SetBodyTextures(t0, null, null, 1);
                    yield return (object) new WaitForSeconds(0.5f);
                    Vector3 normalized = (Vector3) Random.insideUnitCircle.normalized;
                    cObj.transform.localPosition = new Vector3(0.099f, 0f);
                    yield return (object) new WaitForSeconds(1f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.09f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.08f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.07f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.05f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.04f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.03f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.02f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.position += new Vector3(0.05f, 0f);
                    yield return (object) new WaitForSeconds(0.01f);
                    cObj.transform.localPosition = new Vector3(0.099f, 0f);
                    HeartBreakSound.Play();
                    cObj.GetComponent<SpriteRenderer>().sprite = BrokenHeart;
                    yield return (object) new WaitForSeconds(1.2f);
                    cObj.GetComponent<SpriteRenderer>().enabled = false;
                    var HeartShard = new GameObject("HeartShard");
                    HeartShard.transform.SetParent(Head);
                    HeartShard.layer = 10;
                    HeartShard.transform.rotation = Quaternion.Euler(0f, 0f, Random.Range(-360f, 360f));
                    HeartShard.transform.localScale = new Vector3(1f, 1f);
                    HeartShard.transform.position = Head.position;
                    ShardSprite = HeartShard.AddComponent<SpriteRenderer>();
                    ShardSprite.sprite = HeartShard2;
                    if (IsBlue && !IsGreen && !IsPurple) { 
                        ShardSprite.color = new Color(0, 0, 255);
                    } else if (IsGreen && !IsBlue && !IsPurple) {
                        ShardSprite.color = new Color(0, 255, 0);
                    } else if (IsPurple && !IsBlue && !IsGreen) { 
                        ShardSprite.color = new Color(255, 0, 255);
                    } else { 
                        ShardSprite.color = new Color(255, 0, 0);
                    }
                    var cHeartShard1rb = HeartShard.AddComponent<Rigidbody2D>();
                    HeartShard.FixColliders();
                    GameObject instance = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance2 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance3 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance4 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance5 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    GameObject instance6 = Object.Instantiate<GameObject>(HeartShard, cObj.transform.position, Quaternion.identity);
                    instance.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance2.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance3.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance4.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance5.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    instance6.GetComponent<Rigidbody2D>().AddForce((Vector2) (normalized * 7f * Random.Range(0.5f, 1.3f)), ForceMode2D.Impulse);
                    yield return (object) new WaitForSeconds(2f);
                    Destroy(this.gameObject);
                }

            }
        }
    }
}