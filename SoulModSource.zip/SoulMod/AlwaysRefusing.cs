using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
namespace Mod
{
    public class AlwaysRefusing : MonoBehaviour
    {
        public bool Dead = false;
        public int RefusedAmount = 0;
        public LimbBehaviour BeforeLimb;
        public PersonBehaviour Person;
        public Sprite BrokenHeart = ModAPI.LoadSprite("BrokenHeartNoColor.png");
        public Sprite HeartShapedObject = ModAPI.LoadSprite("HeartNoColor.png");
        //public Sprite SpriteShield = ModAPI.LoadSprite("Shield.png");
        public GameObject cObj;
        public GameObject Shield;
        public SpriteRenderer cSpr;
        public Transform Head;
        public Transform Torso;
        public Transform LTorso;
        public Transform HeadReal;
        public AudioSource UnHeartBreakSound;
        public Rigidbody2D HeadRB;
        public Rigidbody2D TorsoRB;
        public Rigidbody2D MTorsoRB;
        public Rigidbody2D LTorsoRB;

        public void Awake() {
            Person = this.gameObject.GetComponent<PersonBehaviour>();
            Head = this.gameObject.transform.GetChild(6).GetChild(0);
            Torso = this.gameObject.transform.GetChild(6).GetChild(1);
            LTorso = this.gameObject.transform.GetChild(6).GetChild(2);
            HeadReal = this.gameObject.transform.GetChild(5);
            HeadRB = HeadReal.GetComponent<Rigidbody2D>();
            TorsoRB = Head.GetComponent<Rigidbody2D>();
            MTorsoRB = Torso.GetComponent<Rigidbody2D>();
            LTorsoRB = LTorso.GetComponent<Rigidbody2D>();
            cObj = new GameObject("HeartObject");
            cObj.transform.SetParent(Head);
            cObj.transform.localPosition = new Vector3(0.099f, 0f);
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            cObj.transform.localScale = new Vector3(1.1f, 1.1f);
            cSpr = cObj.AddComponent<SpriteRenderer>();
            cSpr .sprite = HeartShapedObject;
            cSpr.sortingLayerName = "Top";
            UnHeartBreakSound = cObj.AddComponent<AudioSource>();
            UnHeartBreakSound.clip = ModAPI.LoadSound("snd_break1_c.wav");
        }
        void Update() {
            cSpr.color = new Color(255, 0, 0);
            cObj.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            Person.AdrenalineLevel = 1f;
            foreach (LimbBehaviour p2 in Person.Limbs) {
                BeforeLimb = p2;
                p2.BreakingThreshold += 1f;
                p2.CirculationBehaviour.InternalBleedingIntensity *= 0.4f;
                p2.ImpactPainMultiplier *= 0.1f;
                p2.Vitality *= 0.03f;
                p2.SkinMaterialHandler.RottenProgress *= 0.6f;
                foreach (LimbBehaviour p3 in Person.Limbs) {
                    if (p3.gameObject.name == "Head" && p3.Health <= 0f) {
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                    } else if (p3.gameObject.name == "Head" && p3.Broken == true) { 
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasBloodFlow) { 
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasBloodFlow) { 
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                    } else if (p3.gameObject.name == "UpperBody" && !p3.CirculationBehaviour.HasCirculation) { 
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                    } else if (p3.gameObject.name == "Head" && !p3.CirculationBehaviour.HasCirculation) { 
                            StartCoroutine("BreakHeartWait");
                            BeforeLimb.gameObject.layer = 10;
                            BeforeLimb.CirculationBehaviour.HealBleeding();
                            BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = false;
                            BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                    }
                };
            };
        }
        IEnumerator BreakHeartWait() {
            if (Dead == false) {
                Dead = true;
                yield return (object) new WaitForSeconds(1f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.09f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.09f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.08f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.07f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.05f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.04f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.03f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.02f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.02f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.01f);
                cObj.transform.position += new Vector3(-0.05f, 0f, 0f);
                yield return (object) new WaitForSeconds(0.01f);
                cObj.transform.position += new Vector3(0.05f, 0f);
                yield return (object) new WaitForSeconds(0.01f);
                cObj.GetComponent<SpriteRenderer>().sprite = BrokenHeart;
                UnHeartBreakSound.Play();
                yield return (object) new WaitForSeconds(2.5f);
                UnHeartBreakSound.Play();
                cObj.GetComponent<SpriteRenderer>().sprite = HeartShapedObject;
                ModAPI.Notify("* But it refused.");
                yield return (object) new WaitForSeconds(0.5f);
                //BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                foreach (LimbBehaviour p3 in Person.Limbs) {
                    p3.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
                    BeforeLimb.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
                    p3.LungsPunctured = false;
                    p3.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                    BeforeLimb.HealBone();
                    BeforeLimb.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                    BeforeLimb.LungsPunctured = false;
                    BeforeLimb.Health = BeforeLimb.InitialHealth;
                    BeforeLimb.CirculationBehaviour.IsPump = true;
                    BeforeLimb.CirculationBehaviour.BloodFlow = 1f;
                    BeforeLimb.gameObject.layer = 9;
                    p3.Health = p3.InitialHealth;
                    p3.CirculationBehaviour.IsPump = true;
                    p3.CirculationBehaviour.BloodFlow = 1f;
                    p3.gameObject.layer = 9;
                    p3.HealBone();
                }
                Person.Consciousness = 1f;
                Person.ShockLevel = 0.0f;
                Person.PainLevel = 0.0f;
                Person.OxygenLevel = 1f;
                Person.AdrenalineLevel = 1f;
                Dead = false;
                RefusedAmount += 1;  
            }
        }
    }
}