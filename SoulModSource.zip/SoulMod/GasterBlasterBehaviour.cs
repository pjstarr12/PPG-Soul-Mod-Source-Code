using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Mod
{
    public class GasterBlasterBehaviour : MonoBehaviour
    {
        public LineRenderer LineRenderer;
        public AudioSource GasterBlasterSound;
        public LayerMask LayerMask;
        public Vector2 Pos;
        public Vector2 PosRight;

        public void Awake()
        {
            LineRenderer = this.gameObject.AddComponent<LineRenderer>();
            LineRenderer.startColor = new Color(255, 255, 255);
            LineRenderer.endColor = new Color(255, 255, 255);

            GasterBlasterSound = this.gameObject.AddComponent<AudioSource>();

            
            Pos = this.gameObject.transform.position;
            PosRight = this.gameObject.transform.right * 10f;
        }

        public void Use(ActivationPropagation activation) 
        {
            ModAPI.Notify(activation);
            StartCoroutine(NormalFireRoutine());
        }
        public IEnumerator NormalFireRoutine()
        {
            //ModAPI.Notify("started");
            RaycastHit2D raycastHit2D = Physics2D.Raycast(this.gameObject.transform.position, this.gameObject.transform.right * 10);
            //ModAPI.Notify("Raycasting");
            if (raycastHit2D.collider != null)
            {
                //ModAPI.Notify("Raycast hit"); //fix NOW
                
                DrawLine(Pos, PosRight, new Color(255, 255, 255), 1f);
                this.gameObject.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("GasterBlaster2.png");
                yield return (object) new WaitForSeconds(1f);
                this.gameObject.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("GasterBlaster1.png");
              //OnHit(raycastHit2D.transform, (Vector3) raycastHit2D.point);
            }
            else
            {
                DrawLine(Pos, PosRight, new Color(255, 255, 255), 1f);
                this.gameObject.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("GasterBlaster2.png");
                yield return (object) new WaitForSeconds(1f);
                this.gameObject.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("GasterBlaster1.png");
            }
            //GasterBlasterSound.Play();
            
        }
         void DrawLine(Vector3 start, Vector3 end, Color color, float duration = 0.2f)
         {
             GameObject myLine = new GameObject();
             myLine.transform.position = start;
             myLine.AddComponent<LineRenderer>();
             LineRenderer lr = myLine.GetComponent<LineRenderer>();
             lr.material = new Material(Shader.Find("Particles/Alpha Blended Premultiply"));
             lr.SetColors(color, color);
             lr.SetWidth(0.1f, 0.1f);
             lr.SetPosition(0, start);
             lr.SetPosition(1, end);
             GameObject.Destroy(myLine, duration);
         }
    }
}
