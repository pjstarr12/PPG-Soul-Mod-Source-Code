using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace Mod
{
    public class SoulAbsorb : MonoBehaviour
    {

        private void OnCollisionEnter(Collision other) {
            if (other.gameObject.name == "UpperTorso") { 
                if (!other.gameObject.GetComponent<LimbBehaviour>().Person.gameObject.GetComponent<HeartBehaviourBACKUP>()) { 
                    other.gameObject.GetComponent<LimbBehaviour>().Person.gameObject.AddComponent<HeartBehaviourBACKUP>();
                } else if (!other.gameObject.GetComponent<LimbBehaviour>().Person.gameObject.GetComponent<MonsterSoulBehaviour>()) { 
                    other.gameObject.GetComponent<LimbBehaviour>().Person.gameObject.AddComponent<HeartBehaviourBACKUP>();
                }
            } 
        }
    }
}