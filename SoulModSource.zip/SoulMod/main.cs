using UnityEngine; 
using System.Collections;
namespace Mod
{
    public class Mod
    {
        public static void Main()
        { 

            //LIQUID REGISTERS

            ModAPI.RegisterLiquid(SoulInjector.SoulInjectorSerum.ID, new SoulInjector.SoulInjectorSerum());  
            ModAPI.RegisterLiquid(DeterminationSyringe.DeterminationSerum.ID, new DeterminationSyringe.DeterminationSerum());  
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "Human with a SOUL -HSM",
        DescriptionOverride = "",
        CategoryOverride = ModAPI.FindCategory("Entities"),
        ThumbnailOverride = ModAPI.LoadSprite("HumanThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("BaseSkin.png");
            var flesh = ModAPI.LoadTexture("defaultflesh.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<HeartBehaviourBACKUP>();
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "Non-Fading Human with a SOUL -HSM",
        DescriptionOverride = "",
        CategoryOverride = ModAPI.FindCategory("Entities"),
        ThumbnailOverride = ModAPI.LoadSprite("NFThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("BaseSkin.png");
            var flesh = ModAPI.LoadTexture("defaultflesh.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<NonFading>();
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "Monster with a SOUL -HSM",
        DescriptionOverride = "",
        CategoryOverride = ModAPI.FindCategory("Entities"),
        ThumbnailOverride = ModAPI.LoadSprite("MonsterThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("BaseSkin.png");
            var flesh = ModAPI.LoadTexture("defaultflesh.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<MonsterSoulBehaviour>();
        }
    }
);

ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "sans -HSM",
        DescriptionOverride = "",
        CategoryOverride = ModAPI.FindCategory("Entities"),
        ThumbnailOverride = ModAPI.LoadSprite("SansUndertaleThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("SansUndertale.png");
            var flesh = ModAPI.LoadTexture("defaultbone.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<MonsterSoulBehaviour>();
            foreach (LimbBehaviour p2 in person.Limbs) {
                if (p2.gameObject.name == "LowerArm") { 
                    //p2.gameObject.AddComponent<SansAttack>();
                } else if (p2.gameObject.name == "LowerArmFront") { 
                    //p2.gameObject.AddComponent<SansAttack>();
                }
            }
        }
    }
);

ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "TestSoulForSomeone -HSM",
        DescriptionOverride = "",
        CategoryOverride = ModAPI.FindCategory(""),
        ThumbnailOverride = ModAPI.LoadSprite("HumanThumbex.png"), //make experimental sign
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("BaseSkin.png");
            var flesh = ModAPI.LoadTexture("defaultflesh.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<HeartBehaviour>();
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "Custom Human Soul -HSM",
        DescriptionOverride = "In the context menu, you can set the color of the SOUL. Currently, it dosent work.",
        CategoryOverride = ModAPI.FindCategory(""),
        ThumbnailOverride = ModAPI.LoadSprite("CustomHumanThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("BaseSkin.png");
            var flesh = ModAPI.LoadTexture("defaultflesh.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<CustomHeartBehaviour>();
        }
    }
);

ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "Experimental-Normal Human -HSM",
        DescriptionOverride = "This human was supposed to be a replacement for me if anything breaks.",
        CategoryOverride = ModAPI.FindCategory(""),
        ThumbnailOverride = ModAPI.LoadSprite("what.png"),
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("BaseSkin.png");
            var flesh = ModAPI.LoadTexture("defaultflesh.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<BIRBehaviour>();
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Human"),
        NameOverride = "Always Refusing Human -HSM",
        DescriptionOverride = "This Human always refuses.",
        CategoryOverride = ModAPI.FindCategory("Entities"),
        ThumbnailOverride = ModAPI.LoadSprite("AWThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var skin = ModAPI.LoadTexture("BaseSkin.png");
            var flesh = ModAPI.LoadTexture("defaultflesh.png");
            var bone = ModAPI.LoadTexture("defaultbone.png");
            var person = Instance.GetComponent<PersonBehaviour>();
            person.SetBodyTextures(skin, flesh, bone, 1);
            person.SetBruiseColor(86, 62, 130);
            person.SetSecondBruiseColor(154, 0, 7);
            person.SetThirdBruiseColor(207, 206, 120);
            person.SetRottenColour(202, 199, 104);
            person.SetBloodColour(108, 0, 4);
            Instance.AddComponent<AlwaysRefusing>();
        }
    }
);

ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Knife"),
        NameOverride = "Bone Knife -HSM",
        DescriptionOverride = "Press 'F' or use a wire on it to launch it the direction it is facing.",
        CategoryOverride = ModAPI.FindCategory("Melee"),
        ThumbnailOverride = ModAPI.LoadSprite("BoneKnifeThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var sp = Instance.GetComponent<SpriteRenderer>();
            sp.sprite = ModAPI.LoadSprite("BoneKnife.png");
            Instance.FixColliders();
            Instance.AddComponent<BoneAttack1Behaviour>();
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Sword"),
        NameOverride = "Bone Sword -HSM",
        DescriptionOverride = "Press 'F' or use a wire on it to launch it the direction it is facing.",
        CategoryOverride = ModAPI.FindCategory("Melee"),
        ThumbnailOverride = ModAPI.LoadSprite("BoneSwordThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var sp = Instance.GetComponent<SpriteRenderer>();
            sp.sprite = ModAPI.LoadSprite("BoneSword.png");
            Instance.FixColliders();
            Instance.AddComponent<BoneAttack1Behaviour>();
        }
    }
);

ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Plastic Barrel"),
        NameOverride = "Green Soul Shield -HSM",
        DescriptionOverride = "Just a prop.",
        CategoryOverride = ModAPI.FindCategory("Melee"),
        ThumbnailOverride = ModAPI.LoadSprite("ShieldThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var sp = Instance.GetComponent<SpriteRenderer>();
            sp.sprite = ModAPI.LoadSprite("Shield.png");
            Instance.FixColliders();
            //HeartBehaviourBACKUP.Shield = Instance;
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Knife"),
        NameOverride = "Real Knife -HSM",
        DescriptionOverride = "In my opinion, the texture looks really bad...",
        CategoryOverride = ModAPI.FindCategory("Melee"),
        ThumbnailOverride = ModAPI.LoadSprite("RealKnifeThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var sp = Instance.GetComponent<SpriteRenderer>();
            sp.sprite = ModAPI.LoadSprite("RealKnife.png");
            Instance.FixColliders();
            Instance.AddComponent<BoneAttack1Behaviour>();
            //HeartBehaviourBACKUP.Shield = Instance;
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Sword"),
        NameOverride = "Spear -HSM",
        DescriptionOverride = "In my opinion, the texture looks really bad...",
        CategoryOverride = ModAPI.FindCategory("Melee"),
        ThumbnailOverride = ModAPI.LoadSprite("SpearThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var sp = Instance.GetComponent<SpriteRenderer>();
            sp.sprite = ModAPI.LoadSprite("Spear.png");
            Instance.FixColliders();
            //HeartBehaviourBACKUP.Shield = Instance;
        }
    }
);

ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Plastic Barrel"),
        NameOverride = "Red Heart Object -HSM",
        DescriptionOverride = "",
        CategoryOverride = ModAPI.FindCategory("Melee"),
        ThumbnailOverride = ModAPI.LoadSprite("HeartThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var sp = Instance.GetComponent<SpriteRenderer>();
            sp.sprite = ModAPI.LoadSprite("HeartNoColor.png");
            sp.color = new Color(255, 0, 0);
            Instance.AddComponent<BreakableSoul>();
            Instance.AddComponent<SoulAbsorb>();
            Instance.FixColliders();
        }
    }
);
//ModAPI.Register(
//    new Modification()
//    {
//        OriginalItem = ModAPI.FindSpawnable("Plastic Barrel"),
//        NameOverride = "Yellow Heart Object -HSM",
//        DescriptionOverride = "",
//        CategoryOverride = ModAPI.FindCategory("Melee"),
//        ThumbnailOverride = ModAPI.LoadSprite("YellowHeartThumb.png"),
//        AfterSpawn = (Instance) =>
//        {
//            var sp = Instance.GetComponent<SpriteRenderer>();
//            sp.sprite = ModAPI.LoadSprite("HeartNoColor.png");
//            sp.color = new Color(255, 255, 0);
//            //Instance.transform.localScale = new Vector2(1.2f, 1.2f);
//            //Instance.AddComponent<BreakableSoul>();
//            Instance.FixColliders();
//        }
//    }
//);
//
//ModAPI.Register(
//    new Modification()
//    {
//        OriginalItem = ModAPI.FindSpawnable("Plastic Barrel"),
//        NameOverride = "Green Heart Object -HSM",
//        DescriptionOverride = "",
//        CategoryOverride = ModAPI.FindCategory("Melee"),
//        ThumbnailOverride = ModAPI.LoadSprite("GreenHeartThumb.png"),
//        AfterSpawn = (Instance) =>
//        {
//            var sp = Instance.GetComponent<SpriteRenderer>();
//            sp.sprite = ModAPI.LoadSprite("HeartNoColor.png");
//            sp.color = new Color(0, 255, 0);
//            //Instance.transform.localScale = new Vector2(1.2f, 1.2f);
//            //Instance.AddComponent<BreakableSoul>();
//            Instance.FixColliders();
//        }
//    }
//);
//
//ModAPI.Register(
//    new Modification()
//    {
//        OriginalItem = ModAPI.FindSpawnable("Plastic Barrel"),
//        NameOverride = "Purple Heart Object -HSM",
//        DescriptionOverride = "",
//        CategoryOverride = ModAPI.FindCategory("Melee"),
//        ThumbnailOverride = ModAPI.LoadSprite("PurpleHeartThumb.png"),
//        AfterSpawn = (Instance) =>
//        {
//            var sp = Instance.GetComponent<SpriteRenderer>();
//            sp.sprite = ModAPI.LoadSprite("HeartNoColor.png");
//            sp.color = new Color(255, 0, 255);
//            //Instance.transform.localScale = new Vector2(1.2f, 1.2f);
//            //Instance.AddComponent<BreakableSoul>();
//            Instance.FixColliders();
//        }
//    }
//);
//
//ModAPI.Register(
//    new Modification()
//    {
//        OriginalItem = ModAPI.FindSpawnable("Plastic Barrel"),
//        NameOverride = "Blue Heart Object -HSM",
//        DescriptionOverride = "",
//        CategoryOverride = ModAPI.FindCategory("Melee"),
//        ThumbnailOverride = ModAPI.LoadSprite("BlueHeartThumb.png"),
//        AfterSpawn = (Instance) =>
//        {
//            var sp = Instance.GetComponent<SpriteRenderer>();
//            sp.sprite = ModAPI.LoadSprite("HeartNoColor.png");
//            sp.color = new Color(0, 0, 255);
//            //Instance.transform.localScale = new Vector2(1.2f, 1.2f);
//            //Instance.AddComponent<BreakableSoul>();
//            Instance.FixColliders();
//        }
//    }
//);
//
//ModAPI.Register(
//    new Modification()
//    {
//        OriginalItem = ModAPI.FindSpawnable("Plastic Barrel"),
//        NameOverride = "Orange Heart Object -HSM",
//        DescriptionOverride = "",
//        CategoryOverride = ModAPI.FindCategory("Melee"),
//        ThumbnailOverride = ModAPI.LoadSprite("OrangeHeartThumb.png"),
//        AfterSpawn = (Instance) =>
//        {
//            var sp = Instance.GetComponent<SpriteRenderer>();
//            sp.sprite = ModAPI.LoadSprite("HeartNoColor.png");
//            sp.color = new Color(255, 106, 0);
//            //Instance.transform.localScale = new Vector2(1.2f, 1.2f);
//            //Instance.AddComponent<BreakableSoul>();
//            Instance.FixColliders();
//        }
//    }
//);


ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Beam Rifle"),
        NameOverride = "Gaster Blaster -HSM",
        DescriptionOverride = "DOES NOT WORK",
        CategoryOverride = ModAPI.FindCategory("Melee"),
        ThumbnailOverride = ModAPI.LoadSprite("GasterBlasterThumb.png"),
        AfterSpawn = (Instance) =>
        {
            var sp = Instance.GetComponent<SpriteRenderer>();
            sp.sprite = ModAPI.LoadSprite("GasterBlaster1.png");
            //sp.color = new Color(255, 0, 0);
            //Instance.transform.localScale = new Vector2(1.2f, 1.2f);
            //Instance.AddComponent<BreakableSoul>();
            Instance.FixColliders();
            //Instance.GetComponent<BeamCannonBehaviour>().LineRenderer.startColor = new Color(255, 255, 255);
            //Instance.GetComponent<BeamCannonBehaviour>().LineRenderer.endColor = new Color(255, 255, 255);
            //Instance.GetComponent<BeamCannonBehaviour>().LineRenderer.startWidth = 4f;
            //Instance.AddComponent<GasterBlasterBehaviour>();
            //HeartBehaviourBACKUP.Shield = Instance;
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Brick"),
        NameOverride = "[THIS DOSENT WORK!!!] Soul Activator -HSM",
        DescriptionOverride = "[THIS DOSENT WORK!!!] Spawn this in so all the humans have souls.",
        CategoryOverride = ModAPI.FindCategory(""),
        ThumbnailOverride = ModAPI.LoadSprite("ActivationThumb.png"),
        AfterSpawn = (Instance) =>
        {
            Instance.GetComponent<SpriteRenderer>().enabled = false;
            UnityEngine.Object.Destroy(Instance.GetComponent<PhysicalBehaviour>());
            UnityEngine.Object.Destroy(Instance.GetComponent<BoxCollider2D>());
            UnityEngine.Object.Destroy(Instance.GetComponent<Rigidbody2D>());
            AutoActivator QS = Instance.AddComponent<AutoActivator>();
		    QS.doActivator = true;
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Acid Syringe"),
        NameOverride = "[THIS DOSENT WORK!!!] SOUL Injector -HSM",
        DescriptionOverride = "[THIS DOSENT WORK!!!] Inject this in a human and to give them a SOUL.",
        CategoryOverride = ModAPI.FindCategory(""),
        ThumbnailOverride = ModAPI.LoadSprite("InjectorThumb.png"),
        AfterSpawn = (Instance) =>
        {
            UnityEngine.Object.Destroy(Instance.GetComponent<SyringeBehaviour>());
            Instance.GetOrAddComponent<SoulInjector>();
        }
    }
);
ModAPI.Register(
    new Modification()
    {
        OriginalItem = ModAPI.FindSpawnable("Acid Syringe"),
        NameOverride = "Determination Syringe -HSM",
        DescriptionOverride = "Inject this in a human and to increase their chance of refusing.",
        CategoryOverride = ModAPI.FindCategory("Biohazard"),
        ThumbnailOverride = ModAPI.LoadSprite("DThumb.png"),
        AfterSpawn = (Instance) =>
        {
            UnityEngine.Object.Destroy(Instance.GetComponent<SyringeBehaviour>());
            Instance.GetOrAddComponent<DeterminationSyringe>();
        }
    }
);


//ModAPI.Register(
//    new Modification()
//    {
//        OriginalItem = ModAPI.FindSpawnable("Rod"),
//        NameOverride = "Test",
//        DescriptionOverride = "",
//        CategoryOverride = ModAPI.FindCategory("Melee"),
//        ThumbnailOverride = ModAPI.LoadSprite("ShieldThumb.png"),
//        AfterSpawn = (Instance) =>
//        {
//            //var sp = Instance.GetComponent<SpriteRenderer>();
//            //sp.sprite = ModAPI.LoadSprite("Shield.png");
//            //Instance.FixColliders();
//            Instance.GetComponent<BoneAttack1Behaviour>();
//            //HeartBehaviourBACKUP.Shield = Instance;
//        }
//    }
//);



        }
    }
    public class SoulInjector : SyringeBehaviour
    {
        public override string GetLiquidID() => SoulInjectorSerum.ID;
        public class SoulInjectorSerum : Liquid
        {
            public const string ID = "SoulLiqid";
            public SoulInjectorSerum()
            {
                Color = new UnityEngine.Color(0.69f, 1f, 0.35f);
            }
            public override void OnEnterLimb(LimbBehaviour limb)
            {
                //limb.Person.gameObject.AddComponent<HeartBehaviourBACKUP>();
                if (limb.Person.gameObject.GetComponent<HeartBehaviourBACKUP>())
                {
                    ModAPI.Notify("Person has a SOUL!");
                    return;
                }
                ModAPI.Notify("Person does not have a SOUL!");
                limb.Person.gameObject.AddComponent<HeartBehaviourBACKUP>();
                ModAPI.Notify(limb.Person.gameObject.GetComponent<HeartBehaviourBACKUP>());
            }
            public override void OnUpdate(BloodContainer container) {}
            public override void OnEnterContainer(BloodContainer container) {}
            public override void OnExitContainer(BloodContainer container) {}
        }
    }
    public class DeterminationSyringe : SyringeBehaviour
    {
        public override string GetLiquidID() => DeterminationSerum.ID;
        public class DeterminationSerum : Liquid
        {
            public bool d = false;
            public const string ID = "DeterminationLiquid";
            public DeterminationSerum()
            {
                Color = new Color(255, 0, 0);
            }
            public override void OnEnterLimb(LimbBehaviour limb)
            {
                //limb.Person.gameObject.AddComponent<HeartBehaviourBACKUP>();
                HeartBehaviourBACKUP HB = limb.Person.gameObject.GetComponent<HeartBehaviourBACKUP>();
                if (HB)
                {
                    if (!d) { 
                        d = true;
                        HB.ChanceToRefuse -= 2;
                        ModAPI.Notify(HB.ChanceToRefuse);
                        if (HB.ChanceToRefuse < 0) { 
                            HB.ChanceToRefuse = 0;
                        }
                        //StartCoroutine(ExampleCoroutine());
                    }

                    //ModAPI.Notify(HB.ChanceToRefuse);
                }
                if (limb.Person.gameObject.GetComponent<AlwaysRefusing>()) { 
                    ModAPI.Notify("This wont work on someone who always refuses!");
                }
            }
            public override void OnUpdate(BloodContainer container) {}
            public override void OnEnterContainer(BloodContainer container) {}
            public override void OnExitContainer(BloodContainer container) {}
            IEnumerator ExampleCoroutine() { 
                yield return new WaitForSeconds(1f);
                d = false;
            }
        }
    }
}
public class BreakableSoul : DestroyableBehaviour
{
  public const int ShardCount = 4;
  private SpriteRenderer spriteRenderer;
  public Sprite HeartShard2 = ModAPI.LoadSprite("HeartShard1NoColor.png");

  protected override void Awake()
  {
    base.Awake();
    spriteRenderer.color = new Color(255, 0, 0);
    this.spriteRenderer = this.GetComponent<SpriteRenderer>();
    this.spriteRenderer.sprite = HeartShard2;
  }

  protected override void Update() => base.Update();

  protected override void OnDebrisCreated(GameObject createdDebris, Vector2 velocity)
  {
    createdDebris.GetComponent<VaseDebrisBehaviour>().SetSprite(this.spriteRenderer.sprite);
    base.OnDebrisCreated(createdDebris, velocity);
  }
}
