using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace Mod
{
    public class AutoActivator : MonoBehaviour
    {
        public static AutoActivator inst = null;
        public bool doActivator = false;      
    void Awake(){
        CatalogBehaviour CG = (CatalogBehaviour)FindObjectOfType(typeof(CatalogBehaviour));
        if(inst == null) {
            inst = this;
            //DontDestroyOnLoad(gameObject);
            //DontDestroyOnLoad(this);
            CatalogBehaviour.SpawnedGameObjects.Remove(gameObject);
            this.gameObject.layer = 31;
			if (doActivator){

			}
			else {

			}
			

		}
        else
            Destroy(gameObject);
    }        
        void Update(){
		    if (doActivator){
		    	PersonBehaviour[] people = FindObjectsOfType<PersonBehaviour>();
		    	foreach (PersonBehaviour person in people) {
		    		HeartBehaviourBACKUP AH = person.gameObject.GetComponent<HeartBehaviourBACKUP>();
		    		if(!AH) {
		    			person.gameObject.AddComponent<HeartBehaviourBACKUP>();
		    		}
		    	}
		    }
        }
    }
}